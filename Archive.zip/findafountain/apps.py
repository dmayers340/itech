from django.apps import AppConfig


class WaterfountainConfig(AppConfig):
    name = 'waterfountain'

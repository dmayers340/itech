from django.contrib import admin
from findafountain.models import UserProfile, Fountain
# Register your models here.
admin.site.register(UserProfile)
admin.site.register(Fountain)